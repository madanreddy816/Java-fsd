package com.ecommerce.repository;

public class ProductRepository {

}
