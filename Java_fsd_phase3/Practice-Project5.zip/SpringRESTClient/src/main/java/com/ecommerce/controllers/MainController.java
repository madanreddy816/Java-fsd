package com.ecommerce.controllers;

import org.springframework.http.*;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ecommerce.beans.Quote;
import java.nio.charset.StandardCharsets;
import com.fasterxml.jackson.core.JsonProcessingException;

import java.util.Collections;

@Controller
public class MainController {

    @RequestMapping("/")
    @ResponseBody
    public String index() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        HttpEntity<String> entity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        
        ResponseEntity<String> response = restTemplate.exchange(
                "https://type.fit/api/quotes",
                HttpMethod.GET,
                entity,
                String.class);

        if (response.getStatusCode() == HttpStatus.OK) {
            try {
                String responseBody = response.getBody();
                // Convert the plain text response to an array of Quote objects
                Quote[] quotes = new ObjectMapper().readValue(responseBody, Quote[].class);
                
                // Process each Quote object in the array
                StringBuilder result = new StringBuilder();
                for (Quote quote : quotes) {
                    result.append(quote.toString()).append("\n");
                }
                return result.toString();
            } catch (JsonProcessingException e) {
                e.printStackTrace(); // Handle the exception as per your application's requirement
                return "Error processing JSON response";
            }
        } else {
            return "Failed to fetch quotes. Status code: " + response.getStatusCodeValue();
        }
    }        
}
