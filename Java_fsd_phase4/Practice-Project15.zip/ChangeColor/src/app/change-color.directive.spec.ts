import { ChangeColorDirective } from './change-color.directive';

describe('ChangeColorDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeColorDirective();
    expect(directive).toBeTruthy();
  });
});
