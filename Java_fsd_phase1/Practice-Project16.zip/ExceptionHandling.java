package practice_project;
import java.util.Scanner;

public class ExceptionHandling
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        try 
        {
            // Ask the user to enter two numbers
            System.out.print("Enter the first number: ");
            int num1 = sc.nextInt();

            System.out.print("Enter the second number: ");
            int num2 = sc.nextInt();

            // Perform division 
            int result = num1 / num2;
            System.out.println("Result of division: " + result);
        } 
        catch (ArithmeticException e) 
        {
            // Catch division by zero exception
            System.out.println("Division by zero is not allowed.");
        } 
        catch (Exception e)
        {
            // Catch any other exceptions
            System.out.println("Please chech input and retry " );
        }
        finally 
        {
            System.out.println("Finnaly block is excuted");
        }
    }
}
