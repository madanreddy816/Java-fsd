package practice_project;
import java.util.Scanner;
//Custom exception for handling underage voters
class UnderAgeException extends Exception 
{
 public UnderAgeException(String message) 
 {
     super(message);
 }
}
//Voter class representing a person with an age
class Voter 
{
 private int age;

 public Voter(int age)
 {
     this.age = age;
 }

 // Method to verify if the voter is eligible
 public void verifyEligibility() throws UnderAgeException 
 {
     if (age < 18) 
     {
         throw new UnderAgeException("Voter must be at least 18 years old.");
     } else {
         System.out.println("Voter is eligible!");
     }
 }
}

public class CustomException 
{
 public static void main(String[] args) 
 {
     Scanner sc = new Scanner(System.in);

     System.out.print("Enter voter's age: ");
     int age = sc.nextInt();

     Voter v = new Voter(age);

     try
     {
         v.verifyEligibility();
     } 
     catch (UnderAgeException e) 
     {
         System.out.println("Error: " + e.getMessage());
     }
     finally 
     {
         System.out.println("Verification is completed");
     }
 }
}
