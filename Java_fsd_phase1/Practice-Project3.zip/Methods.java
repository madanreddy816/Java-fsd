package practice_project;


public class Methods 
{
	//method overload with parameters
	public void add(int a,int b)
	{
		int sum=a+b;
		System.out.println("Sum of 2 numbers with parameters "+sum);
	}
	
	public void add(int x,int y,int z)
	{
		int sum=x+y+z;
		System.out.println("Sum of 2 numbers with parameters "+sum);
	}
	
	//non-static method
	public int mul()
	{
		int p=5,q=6;
		return p*q;
	}
	
	public int mul(int c,int d)
	{
		return c*d;
	}
	
	// static method
	public static void sub()
	{
		int e=10,f=5;
		int dif=e-f;
		System.out.println("Differenece of 2 numbers without parameters " +dif);
	}

	public static void sub(int g,int h)
	{
		int dif=g-h;
		System.out.println("Differenece of 2 numbers with parameters "+ dif);
	}
	
	
	public static void main(String[] args)
	{
		Methods m=new Methods();
		m.add(15,20);
		m.add(15,20,25);
		int result=m.mul();
		System.out.println("Multiplication of 2 numbers without parameters "+ result);
		
		int i=9,j=10;
		int res=m.mul(i, j);
		System.out.println("Multiplication of 2 numbers with parameters "+ res);
		
		m.sub();
		m.sub(50,25);
	}
}
