package practice_project;
import java.util.Arrays;

public class FourthSmallest 
{
    public static int findFourthSmallest(int[] arr)
    {
        if (arr == null || arr.length < 4) 
        {
            System.out.println("Input array is null or has less than 4 elements.");
            return -1; 
        }

        // Sort the array in ascending order
        Arrays.sort(arr);

        // The fourth smallest element will be at index 3
        return arr[3];
    }

    public static void main(String[] args) 
    {
        int[] arr = {12,9,5,4,8,15,76,19}; // Sample unsorted array
        findFourthSmallest(arr);
        if (findFourthSmallest(arr) != -1) 
        {
            System.out.println("The fourth smallest element in the array is: " +findFourthSmallest(arr));
        }
    }
}

