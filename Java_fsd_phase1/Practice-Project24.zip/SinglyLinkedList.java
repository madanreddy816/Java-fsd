package practice_project;
import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) 
    {
        this.data = data;
        this.next = null;
    }
}

public class SinglyLinkedList 
{

    private Node head;

    public SinglyLinkedList()
    {
        this.head = null;
    }

    public void insert(int data) 
    {
        Node newNode = new Node(data);
        if (head == null) 
        {
            head = newNode;
        } 
        else 
        {
            Node temp = head;
            while (temp.next != null) 
            {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    public void delete(int key) 
    {
        Node prev = null;
        Node current = head;

        if (current != null && current.data == key)
        {
            head = current.next;
            return;
        }
        while (current != null && current.data != key) 
        {
            prev = current;
            current = current.next;
        }

        // If the key was not present in the linked list
        if (current == null) 
        {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Unlink the node from the linked list
        prev.next = current.next;
    }

    public void display() 
    {
        Node temp = head;
        while (temp != null)
        {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) 
    {
        SinglyLinkedList list = new SinglyLinkedList();
        // Predefined values for the linked list
        int[] values = { 10, 20, 30, 40, 50 };
        for (int value : values)
        {
           list.insert(value);
       	}
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the key to delete from Linked List");
        int keyDeletion=sc.nextInt();
        System.out.println("Original linked list:");
        list.display();
        list.delete(keyDeletion);
        System.out.println("Linked list after deleting key " + keyDeletion + ":");
        list.display();
    }
}
