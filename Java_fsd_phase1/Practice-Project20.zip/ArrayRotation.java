package practice_project;
public class ArrayRotation 
{
    public static void display(int arr[]) 
    {
        for(int z : arr) 
        {
            System.out.print(z + " ");
        }
    }

    public static void main(String[] args) 
    {
        int arr[] = new int[] {1, 2, 3, 4, 5, 6, 7, 8};
        int steps = 5;
        int l = arr.length;
        System.out.print("Array before rotating: ");
        display(arr);

        for(int i = 0; i < steps; i++) 
        {
            int temp = arr[l - 1];
            for(int j = l - 1; j > 0; j--)
            {
                arr[j] = arr[j - 1];
            }
            arr[0] = temp;
        }

        System.out.print("\nArray after rotating 5 steps to the right: ");
        display(arr);
    }
}
