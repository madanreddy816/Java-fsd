package practice_project;

class student
{
	int studentId;
	String name;
	 
	student()
	{
	}
	void disp()
	{
		System.out.println("Student Id is" + studentId);
		System.out.println("Student Name " +name);
	}

}

class Employee
{
	int EmployeeId;
	int EmployeeAge;
	String EmployeeName;
	
	Employee(int id,int age,String name)
	{
		EmployeeId=id;
		EmployeeAge=age;
		EmployeeName=name;
	}
	void display()
	{
		System.out.println("Employee Id " +EmployeeId);
		System.out.println("Employee Aged" +EmployeeAge);
		System.out.println("Employee Name "+EmployeeName);
	}
}

public class Constructors
{
	public static void main(String[] args)
	{
		student s=new student();
		s.studentId=1001;
		s.name="Alex";
		System.out.println("Default Constructor");
		s.disp();
		
		
		Employee e1=new Employee(11,24,"Samuel");
		Employee e2=new Employee(12,25,"Jack");
		System.out.println("Parametarized Constructor");
		e1.display();
		e2.display();
		
	}
}
