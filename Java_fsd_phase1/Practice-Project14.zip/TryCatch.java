package practice_project;

import java.util.Scanner;

public class TryCatch 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter two numbers to divide:");
        try {
            int num1 = sc.nextInt();
            int num2 = sc.nextInt();
            int result = num1 / num2;

            System.out.println("Result of division " + result);
        }
        catch (ArithmeticException e) 
        {
            // Catch division by zero exception
            System.out.println("Division by zero is possible.");
        } 
        catch (Exception e) 
        {
            // Catch any other exceptions
            System.out.println("Please check the input and retry.");
        }

    }
}
