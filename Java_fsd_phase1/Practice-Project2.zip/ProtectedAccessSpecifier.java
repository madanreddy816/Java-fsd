package practice_project;

// Parent class
class Parent 
{
    protected int value;
    public Parent() 
    {
        value = 100;
    }

    // Method to display value
    protected void display() {
        System.out.println("Protected Value: " + value);
    }
}
// Child class inheriting from Parent class
class Child extends Parent 
{
    private int num;

    public Child() 
    {
        num = 50;
    }

    // Method to display private number
    public void disp() 
    {
        System.out.println("Private number : " + num);
    }
}

public class ProtectedAccessSpecifier 
{
    public static void main(String[] args)
    {
        Child c = new Child();

        // Accessing value and method from Child class
        c.display();

        // Accessing public method of Child class
        c.disp();
    }
}
