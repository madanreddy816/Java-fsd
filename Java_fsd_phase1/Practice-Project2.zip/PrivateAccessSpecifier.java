package practice_project;

public class PrivateAccessSpecifier {
    private int x, y;

    public void setData(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void displayData() {
        System.out.println("X value is : " + x);
        System.out.println("Y value is : " + y);
    }


    public static void main(String[] args) {
        PrivateAccessSpecifier obj = new PrivateAccessSpecifier();

         obj.x = 10; // Can access private member x inside  the class and cause compilation error when we try to access x outside the class
         obj.y = 20; // Can access private member y inside the class and cause compilation error when we try to access y outside the class
         
         //obj.setData(10,20);  //If we need access x & y outside the class we need call along with method
        obj.displayData();
    }
}
