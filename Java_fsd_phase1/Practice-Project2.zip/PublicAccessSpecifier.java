package practice_project;

class Data
{
	// Public member variables
    public int x, y; 

    public void setData(int x, int y) 
    { 
    	// Public method to set data
        this.x = x;
        this.y = y;
    }

    public void displayData()
    { 
    	// Public method to display data
        System.out.println("X value is : " + x);
        System.out.println("Y value is : " + y);
    }
}

public class PublicAccessSpecifier 
{
    public static void main(String[] args) 
    {
        Data d = new Data();

        // Accessing public member variables directly
        d.x = 30;
        d.y = 40;
        d.displayData();
        System.out.println();
        // Accessing public methods
        d.setData(10, 20);
        d.displayData();
    }
}
