package practice_project;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        String regex = "[a-zA-Z]+\\d+";

        // user to enter input string
        System.out.print("Enter the input string to verify: ");
        String input = sc.nextLine();

        // Compile the regular expression
        Pattern pt = Pattern.compile(regex);

        // Create a matcher with the input string
        Matcher match = pt.matcher(input);

        // Verify if input matches the regular expression
        if (match.matches()) 
        {
            System.out.println("Input matches with the regular expression.");
        } 
        else 
        {
            System.out.println("Input does not match with the regular expression.");
        }
    }
}