package practice_project;
import java.util.Scanner;
public class LinearSearch
{
	public static void main(String[] args)
	{
		int arr[]= {1,5,10,2,3,15,6,7,20};
		int search;
		int x=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number to search");
		search=sc.nextInt();
		for(int i=0;i<arr.length;i++)
		{
			if(search==arr[i])
			{
				x=1;
			}
		}
		if(x==1)
		{
			System.out.println("Element Found");
		}
		else
		{
			System.out.println("Element not Found");
		}
	}
}
