package practice_project;
//Common interface
interface Animal 
{
 void eat();
}

//Interface extending Animal
interface Pet extends Animal 
{
 void play();
}

//Another interface extending Animal
interface WildAnimal extends Animal 
{
 void roam();
}

//Class implementing both Pet and WildAnimal interfaces
class Dog implements Pet, WildAnimal
{
 @Override
 public void eat() 
 {
     System.out.println("Dog is eating the food");
 }

 @Override
 public void play() 
 {
     System.out.println("Dog is playing with ball");
 }

 @Override
 public void roam()
 {
     System.out.println("Dog is roaming around the streets");
 }
}

public class ResolveDiamondProblem 
{
 public static void main(String[] args) 
 {
     Dog dog = new Dog();
     dog.eat();     
     dog.play(); 
     dog.roam(); 
 }
}

