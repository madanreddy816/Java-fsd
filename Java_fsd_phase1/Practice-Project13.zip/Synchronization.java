package practice_project;
public class Synchronization 
{
    public static void main(String[] args)
    {
        Counter counter = new Counter();

        // Creating multiple threads that increment the counter concurrently
        Thread t1 = new Thread(new IncrementTask(counter));
        Thread t2 = new Thread(new IncrementTask(counter));

        t1.start();
        t2.start();

        try 
        {
            // Waiting for both threads to finish execution
            t1.join();
            t2.join();
        } 
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        System.out.println("Final counter value: " + counter.getCount());
    }
}

class Counter 
{
    private int count = 0;

    // Synchronized method to increment the counter
    public synchronized void increment() 
    {
        count++;
    }

    // Method to get the counter value
    public int getCount()
    {
        return count;
    }
}

// Task to increment the counter
class IncrementTask implements Runnable
{
    private Counter counter;

    public IncrementTask(Counter counter) 
    {
        this.counter = counter;
    }

    @Override
    public void run()
    {
        for (int i = 0; i < 10; i++)
        {
            counter.increment();
        }
    }
}
