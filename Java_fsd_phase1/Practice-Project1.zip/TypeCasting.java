package practice_project;

public class TypeCasting 
{
	public static void main(String[] args)
	{
		//implicit Type Casting
		int value=50;
		double num=value;// Implicitly casting int to double
		
		System.out.println("double num after implicit casting: " + num);
		
        // Explicit Type Casting
		double d=456.67;
		int i=(int)d; //Explicitly casting double to int
		
		System.out.println("int value after explicit casting: "+ i);
	}
}
