package practice_project;
import java.util.Scanner;
public class BubbleSort 
{
	public static void main(String[] args)
	{
		int arr[]= {23,1,32,2,43,3,54,4};
		for(int i=0;i<arr.length-1;i++)
		{
			for(int j=0;j<arr.length-i-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		System.out.println("The sorted Array is: ");
		for(int x:arr)
		{
			System.out.print(x+" ");
		}
		int search;
		Scanner sc=new Scanner (System.in);
		System.out.println();
		System.out.println("Enter Element to Search");
		search=sc.nextInt();
		int x=0;
		for(int i=0;i<arr.length;i++)
		{
			if(search==arr[i])
				x=1;
		}
		if(x==1)
		{
			System.out.println("Element Found");
		}
		else
		{
			System.out.println("Element Not Found");
		}
	}
}
