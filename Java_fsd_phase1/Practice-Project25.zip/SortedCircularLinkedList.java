package practice_project;

class CircularLinkedList 
{
    private static class Node 
    {
        int data;
        Node next;

        public Node(int data) 
        {
            this.data = data;
            this.next = null;
        }
    }

    Node head;

    // Function to insert a new element into the sorted circular linked list
    public void insert(int data) 
    {
        Node newNode = new Node(data);
        if (head == null) 
        {
            head = newNode;
            head.next = head; 
        }
        else 
        {
            Node current = head;
            while (current.next != head && current.next.data < data) 
            {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Function to display the circular linked list
    public void display()
    {
        if (head == null) 
        {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do 
        {
            System.out.print(current.data + " ");
            current = current.next;
        } 
        while (current != head);
        System.out.println();
    }
}

public class SortedCircularLinkedList 
{
    public static void main(String[] args) 
    {
        CircularLinkedList cll= new CircularLinkedList();

        // Predefined sorted values for the circular linked list
        int[] Values = {10, 20, 30, 40, 50};
        for (int value : Values) 
        {
            cll.insert(value);
        }
        // Display the original circular linked list
        System.out.println("Original circular linked list:");
        cll.display();
        // Element to insert
        int elementToInsert = 35;
        cll.insert(elementToInsert);
        int elementToInsert1=25;
        cll.insert(elementToInsert1);
        System.out.println("Updated circular linked list:");
        cll.display();
    }
}
