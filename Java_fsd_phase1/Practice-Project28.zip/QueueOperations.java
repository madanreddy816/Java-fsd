package practice_project;
import java.util.LinkedList;
import java.util.Queue;
public class QueueOperations 
{
    public static void main(String[] args) 
    {
        // Creating a queue
        Queue<String> queue = new LinkedList<>();

        // Inserting elements into the queue
        queue.add("Orange"); 
        queue.add("Yellow"); 
        queue.add("Black"); 
        queue.add("Blue"); 
        queue.add("Red"); 
        queue.add("Violet");

        System.out.println("Initial Queue: " + queue);        
        System.out.println("The head of the Queue : "+queue.peek());
        queue.remove();
        System.out.println("After removing head of the queue: "+queue);
        System.out.println("Size of the queue after removing head: "+ queue.size());
        
    }
}
