package practice_project;
class Stack 
{
    private int maxSize;
    private int[] stackArray; 
    private int top;

    public Stack(int size) 
    {
        this.maxSize = size;
        this.stackArray = new int[maxSize]; 
        this.top = -1;
    }

    public void push(int item) 
    { 
        if (isFull()) 
        {
            System.out.println("Stack is full. Cannot push element.");
        } 
        else 
        {
            top++;
            stackArray[top] = item;
        }
    }

    public int pop() 
    { 
        if (isEmpty())
        {
            System.out.println("Stack is empty. Cannot pop element.");
            return -1; 
        } 
        else 
        {
            int poppedItem = stackArray[top];
            top--;
            return poppedItem;
        }
    }

    public boolean isEmpty()
    {
        return (top == -1);
    }

    public boolean isFull() 
    {
        return (top == maxSize - 1);
    }

    public void displayStack()
    {
        for (int i = 0; i <= top; i++) {
            System.out.print(stackArray[i] + " ");
        }
        System.out.println();
    }
}

public class StackOperations 
{
    public static void main(String[] args)
    {
        Stack s = new Stack(5);
        s.push(9);
        s.push(5);
        s.push(3);
        s.push(7);
        s.push(1);
        System.out.println("After Pushing 4 Elements:");
        s.displayStack();
        System.out.println("After popping a element");
        s.pop();
        s.displayStack();
        
    }
}
