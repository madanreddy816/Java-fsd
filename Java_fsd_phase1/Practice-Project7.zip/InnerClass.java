package practice_project;

public class InnerClass
{
    
    // Static Inner Class
    static class StaticInner 
    {
        public void display() 
        {
            System.out.println("This is Static Inner Class");
        }
    }

    // Non-static Inner Class
    class NonStaticInner 
    {
        public void display()
        {
            System.out.println("This is Non-Static Inner Class");
        }
    }
    
    public void method() 
    {
        // Local Inner Class
        class LocalInner 
        {
            void display() 
            {
                System.out.println("This is Local Inner Class");
            }
        }
        LocalInner obj = new LocalInner();
        obj.display();
    }
    
    public static void main(String[] args) 
    {
        InnerClass a = new InnerClass();
        
        InnerClass.StaticInner b = new InnerClass.StaticInner();
        b.display();
        
        InnerClass.NonStaticInner c = a.new NonStaticInner();
        c.display();
        
        a.method();
        
        // Anonymous Inner Class
        AnonymousInner d = new AnonymousInner() 
        {
            public void show() 
            {
                System.out.println("This is Anonymous Inner Class ");
            }
        };
        d.show(); // Call to the method should be outside the anonymous class instantiation block
    }
}

// Interface
interface AnonymousInner 
{
    public void show();
}
