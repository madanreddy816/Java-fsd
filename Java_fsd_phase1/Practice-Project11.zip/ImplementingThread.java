package practice_project;
//Extending Thread class
class MyThread extends Thread 
{
 public void run() 
 {
     System.out.println("This is the thread created by extending Thread class");
 }
}
//Implementing Runnable interface
class MyRunnable implements Runnable 
{
 public void run() 
 {
     System.out.println("This is the thread created by implementing runnable interface");
 }
}

public class ImplementingThread 
{
 public static void main(String[] args) 
 {
     // Creating thread by extending Thread class
     MyThread thread = new MyThread();
     thread.start();
     // Creating thread by implementing Runnable interface
     MyRunnable Run = new MyRunnable();
     Thread thread2 = new Thread(Run);
     thread2.start();
 }
}
