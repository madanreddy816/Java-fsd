package practice_project;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Maps {
    public static void main(String[] args) {
        // HashMap 
        System.out.println("HashMap");
        Map<Integer, String> hm = new HashMap<>();
        hm.put(1, "Ram");
        hm.put(2, "Laxman");
        hm.put(3, "Bheem");
        
        for (Integer key : hm.keySet()) {
            System.out.println(key + "  " + hm.get(key));
        }

        // TreeMap 
        System.out.println("\nTreeMap");
        Map<Integer, String> tm = new TreeMap<>();
        tm.put(4, "Yellow");
        tm.put(5, "Orange");
        
        for (Integer key : tm.keySet()) {
            System.out.println(key + "  " + tm.get(key));
        }

        // LinkedHashMap 
        System.out.println("\nLinkedHashMap ");
        Map<Integer, Integer> lhm = new LinkedHashMap<>();
        lhm.put(6, 111);
        lhm.put(7, 222);
        lhm.put(8, 333);
        
        for (Integer key : lhm.keySet()) {
            System.out.println(key + "  " + lhm.get(key));
        }

        // Hashtable 
        System.out.println("\nHashtable");
        Map<Integer, String> ht = new Hashtable<>();
        ht.put(9, "Physics");
        ht.put(10, "Maths");
        
        for (Integer key : ht.keySet()) {
            System.out.println(key + "  " + ht.get(key));
        }
    }
}
