package practice_project;

import java.util.Scanner;
public class StringBuffer_StringBuilder
{

	public static void main(String[] args) 
	{
		Scanner scanner = new Scanner(System.in);
        String userInput = "Hello World,I am learning Java Fsd";

        // Create a StringBuffer from the string
        StringBuffer sb = new StringBuffer(userInput);

        // Create a StringBuilder from the string
        StringBuilder sBuilder = new StringBuilder(userInput);

        // Display the original string
        System.out.println("Original String: " + userInput);

        // Display the converted StringBuffer (unchanged)
        System.out.println("Converted to StringBuffer: " + sb);

        // Modify the StringBuilder (demonstrates mutability)
        sBuilder.append(" And This is phase 1");

        // Display the modified StringBuilder
        System.out.println("Modified StringBuilder: " + sBuilder);
    }
}