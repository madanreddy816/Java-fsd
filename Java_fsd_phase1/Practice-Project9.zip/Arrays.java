package practice_project;

public class Arrays 
{
	public static void main(String[] args)
	{
		//Single Dimension Array
		//Integer Array
		int arr[]=new int[7];
		arr[0]=10;
		arr[1]=20;
		arr[2]=30;
		arr[3]=40;
		arr[4]=50;
		arr[5]=60;
		arr[6]=70;
	
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Elements present at index "+i+ " : "+arr[i]);
		}
		
		//String Array
		String names[]= {"Ram","Laxman","Bheem","Rock","James"};
		System.out.println("\n");
		
		for(int i=0;i<names.length;i++)
		{
			System.out.println("Elements present at index "+i+ " : "+names[i]);
		}
		
		//MultiDimensional Array
		
		int[][] multiArray= {
				{10,20,30},
				{40,50,60},
				{70,80,90}
		};
		 System.out.println("\n");
		 System.out.println("Length of row 1: " + multiArray[0].length);
		 
		 for (int i = 0; i < multiArray.length; i++) 
		 {
	            for (int j = 0; j < multiArray[i].length; j++)
	            {
	                System.out.print(multiArray[i][j] + " ");
	            }
	            System.out.println();
	            
		 }
		 
		
	}
		
}

