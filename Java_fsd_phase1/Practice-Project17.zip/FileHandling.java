package practice_project;

import java.io.*;

public class FileHandling {
    // Method to create a new file
    public static void createFile(String fileName)
    {
        try {
            File file = new File(fileName);
            if (file.createNewFile()) 
            {
                System.out.println("File created: " + file.getName());
            } 
            else 
            {
                System.out.println("File already exists.");
            }
        }
        catch (IOException e) 
        {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }

    // Method to read the contents of a file
    public static void readFile(String fileName) 
    {
        try {
            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            System.out.println("File contents:");
            while ((line = bufferedReader.readLine()) != null) 
            {
                System.out.println(line);
            }
            bufferedReader.close();
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }

    // Method to write or update content to a file
    public static void writeFile(String fileName, String content) 
    {
        try 
        {
            FileWriter writer = new FileWriter(fileName);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            bufferedWriter.write(content);
            bufferedWriter.close();
            System.out.println("Content has been written to the file.");
        } 
        catch (IOException e) 
        {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    // Method to delete a file
    public static void deleteFile(String fileName)
    {
        File file = new File(fileName);
        if (file.delete()) 
        {
            System.out.println("File deleted: " + file.getName());
        } 
        else 
        {
            System.out.println("Failed to delete the file.");
        }
    }

    public static void main(String[] args) 
    {
        String fileName = "sample.txt";

        // Create a new file
        createFile(fileName);

        // Write content to the file
        writeFile(fileName, "This is a sample text file.\nIt demonstrates file operations in Java.");

        // Read and display the contents of the file
        readFile(fileName);

        //Update content in the file
        writeFile(fileName, "This content has been updated.");

        // Read and display the updated contents of the file
        readFile(fileName);

        // Delete the file
        deleteFile(fileName);
    }
}
