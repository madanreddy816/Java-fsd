package practice_project;

import java.util.ArrayList;
import java.util.Vector;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.LinkedHashSet;

public class Collections 
{
    public static void main(String[] args) 
    {
        // ArrayList 
        System.out.println("ArrayList ");
        ArrayList<String> al = new ArrayList<>();
        al.add("Apple");
        al.add("Mango");
        al.add("Straw Berry");
        System.out.println("ArrayList: " + al);

        // Vector 
        System.out.println("\nVector ");
        Vector<String> vec = new Vector<>();
        vec.add("Violet");
        vec.add("Indigo");
        vec.add("Black");
        System.out.println("Vector: " + vec);

        // LinkedList 
        System.out.println("\nLinkedList ");
        LinkedList<Integer> l = new LinkedList<>();
        l.add(1);
        l.add(12);
        l.add(13);
        System.out.println("LinkedList: " + l);

        // HashSet 
        System.out.println("\nHashSet ");
        HashSet<String> hs = new HashSet<>();
        hs.add("Cat");
        hs.add("Dog");
        hs.add("Rabbit");
        System.out.println("HashSet: " + hs);

        // LinkedHashSet 
        System.out.println("\nLinkedHashSet ");
        LinkedHashSet<Integer> lh = new LinkedHashSet<>();
        lh.add(22);
        lh.add(33);
        lh.add(55);
        System.out.println("LinkedHashSet: " + lh);

        
    }
}
