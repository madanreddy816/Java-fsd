package practice_project;
//Abstract class representing a shape
abstract class Shape
{
 // Abstract method to calculate area (to be implemented by subclasses)
 public abstract double calculateArea();
}
//Concrete subclass representing a Rectangle
class Rectangle extends Shape 
{
 private double length;
 private double width;
 // Constructor
 public Rectangle(double length, double width) 
 {
     this.length = length;
     this.width = width;
 }
 // Implementation of abstract method to calculate area of rectangle
 @Override
 public double calculateArea() 
 {
     return length * width;
 }
}
//Main class
public class Abstraction 
{
 public static void main(String[] args) 
 {
     // Creating object of Rectangle
     Shape rectangle = new Rectangle(4.0, 6.0);
     // Displaying area of rectangle
     System.out.println("Area of Rectangle: " + rectangle.calculateArea());
 }
}
