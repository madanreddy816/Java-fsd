package practice_project;
//Car class declaration
class Cars {
 // Class variables or attributes
 String brand;
 String model;
 int year;

 // Constructor
 public Cars(String brand, String model, int year) {
     this.brand = brand;
     this.model = model;
     this.year = year;
 }

 // Method to display car information
 public void displayInfo() {
     System.out.println("Brand: " + brand);
     System.out.println("Model: " + model);
     System.out.println("Year: " + year);
 }
}

//Main class
public class ClassDemo {
 public static void main(String[] args) {
     // Creating objects of the Car class
     Cars c1 = new Cars("Toyota", "Cary", 2024);
     Cars c2 = new Cars("Honda", "Splender", 2010);

     // Accessing object properties and methods
     System.out.println("Car 1 Information:");
     c1.displayInfo();

     System.out.println("\nCar 2 Information:");
     c2.displayInfo();
 }
}
