package practice_project;

//Class with encapsulated attributes and methods
class Person 
{
 // Private attributes
 private String name;
 private int age;

 // Public constructor
 public Person(String name, int age) 
 {
     this.name = name;
     this.age = age;
 }

 // Getter method for name
 public String getName() 
 {
     return name;
 }

 // Setter method for name
 public void setName(String name) 
 {
     this.name = name;
 }

 // Getter method for age
 public int getAge() 
 {
     return age;
 }

 // Setter method for age
 public void setAge(int age) 
 {
     if (age >= 0 && age <= 150) 
     {
         this.age = age;
     } 
     else 
     {
         System.out.println("Invalid age. Age must be between 0 and 150.");
     }
 }

 // Method to display person information
 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }
}
//Main class
public class Encapsulation {
 public static void main(String[] args) {
     // Creating object of Person class
     Person person = new Person("Alice", 30);
     // Accessing attributes using getter and setter methods
     person.setName("Bob");
     person.setAge(25);
     // Displaying person information
     person.displayInfo();
 }
}
