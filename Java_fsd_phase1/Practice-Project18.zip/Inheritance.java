package practice_project;
//Parent class
class Vehicles {
 protected String brand;
 protected String model;
 protected int year;

 // Constructor
 public Vehicles(String brand, String model, int year) {
     this.brand = brand;
     this.model = model;
     this.year = year;
 }

 // Method to display vehicle information
 public void displayInfo() {
     System.out.println("Brand: " + brand);
     System.out.println("Model: " + model);
     System.out.println("Year: " + year);
 }
}

//Child class inheriting from Vehicle
class Car6 extends Vehicles {
 private int doors;

 // Constructor
 public Car6(String brand, String model, int year, int doors) {
     super(brand, model, year);
     this.doors = doors;
 }

  @Override
 public void displayInfo() {
     super.displayInfo();
 }
}

//Main class
public class Inheritance {
 public static void main(String[] args) {
     // Creating object of Car
     Car6 car = new Car6("Toyota", "Camry", 2022, 4);

     // Displaying car information
     System.out.println("Car Information:");
     car.displayInfo();
 }
}
