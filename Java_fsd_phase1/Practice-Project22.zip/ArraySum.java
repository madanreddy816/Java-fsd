package practice_project;
import java.util.Scanner;

public class ArraySum 
{
    public static void main(String[] args) 
    {
        int[] array = {3,7,2,5,8,9}; // Predefined array
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the index position to start the sum");
        int L =sc.nextInt(); // starting range to calculate sum
        System.out.println("Enter the index position to end the sum");
        int R = sc.nextInt(); // Ending range to calculate sum
        int n = array.length; // Length of the array

        if (L < 0 || R >= n || L > R) 
        {
            System.out.println("Invalid range!");
            return;
        }
        // calculating sum between the range L to R
        int sum = 0;
        for (int i = L; i <= R; i++) 
        {
            sum =sum+array[i];
        }

        System.out.println("Sum of elements from index " + L + " to " + R + " is " + sum);
    }
}
