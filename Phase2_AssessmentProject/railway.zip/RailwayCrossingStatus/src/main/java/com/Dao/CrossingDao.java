package com.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.model.DBConnection;
import com.model.railwayCrossing;

public class CrossingDao {
    private Connection con;

    public CrossingDao() {
        // Initialize the database connection
        con = DBConnection.getConnection();
    }

    // Fetch all values from the database
    public List<railwayCrossing> getAllCrossings() {
        List<railwayCrossing> crossings = new ArrayList<>();
        try {
            String query = "SELECT * FROM railwaycrossing";
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                railwayCrossing crossing = new railwayCrossing();
                crossing.setId(rs.getInt("id"));
                crossing.setName(rs.getString("name"));
                crossing.setAddress(rs.getString("address"));
                crossing.setLandmark(rs.getString("landmark"));
                crossing.setTrainSchedule(rs.getString("trainSchedule"));
                crossing.setPersonInCharge(rs.getString("personInCcharge"));
                crossing.setStatus(rs.getString("status"));
                crossings.add(crossing);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return crossings;
    }

    public railwayCrossing getCrossingById(int crossingId) {
        railwayCrossing crossing = null;
        try {
            String query = "SELECT * FROM railwaycrossing WHERE id = ?";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, crossingId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                crossing = new railwayCrossing();
                crossing.setId(resultSet.getInt("id"));
                crossing.setName(resultSet.getString("name"));
                crossing.setAddress(resultSet.getString("address"));
                crossing.setLandmark(resultSet.getString("landmark"));
                crossing.setTrainSchedule(resultSet.getString("trainSchedule"));
                crossing.setPersonInCharge(resultSet.getString("personInCcharge"));
                crossing.setStatus(resultSet.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return crossing;
    }

    public void updateCrossing(railwayCrossing crossing) {
        try {
            String query = "UPDATE railwaycrossing SET name=?, address=?,landmark=?,trainSchedule=?, personInCcharge=?, status=? WHERE id=?";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, crossing.getName());
            statement.setString(2, crossing.getAddress());
            statement.setString(3, crossing.getLandmark());
            statement.setString(4, crossing.getTrainSchedule());
            statement.setString(5, crossing.getPersonInCharge());
            statement.setString(6, crossing.getStatus());
            statement.setInt(7, crossing.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCrossing(int crossingId) {
        try {
            con.setAutoCommit(false);
            String deleteRailwayCrossingQuery = "DELETE FROM railwaycrossing WHERE id = ?";
            try (PreparedStatement deleteRailwayCrossingStatement = con.prepareStatement(deleteRailwayCrossingQuery)) {
                deleteRailwayCrossingStatement.setInt(1, crossingId);
                deleteRailwayCrossingStatement.executeUpdate();
            }
            con.commit(); // Commit the transaction
            con.setAutoCommit(true); // Reset auto-commit to true
        } catch (SQLException e) {
            try {
                con.rollback(); // Rollback the transaction if an error
            } catch (SQLException rollbackException) {
                rollbackException.printStackTrace();
            }
            e.printStackTrace();
        }
    }

    public void addCrossing(railwayCrossing crossing) {
        try {
            String query = "INSERT INTO railwaycrossing (name, address, landmark,trainSchedule, personInCcharge, status) VALUES (?, ?, ?, ?, ?,?)";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, crossing.getName());
            statement.setString(2, crossing.getAddress());
            statement.setString(3, crossing.getLandmark());
            statement.setString(4, crossing.getTrainSchedule());
            statement.setString(5, crossing.getPersonInCharge());
            statement.setString(6, crossing.getStatus());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<railwayCrossing> getFavoriteCrossings() {
        List<railwayCrossing> favoriteCrossings = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection()) {
            String query = "SELECT rc.* FROM railwaycrossing rc " + "JOIN favcrossing fc ON rc.id =fc.id";
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                railwayCrossing crossing = new railwayCrossing();
                crossing.setId(resultSet.getInt("id"));
                crossing.setName(resultSet.getString("name"));
                crossing.setAddress(resultSet.getString("address"));
                crossing.setLandmark(resultSet.getString("landmark"));
                crossing.setTrainSchedule(resultSet.getString("trainSchedule"));
                crossing.setPersonInCharge(resultSet.getString("personInCcharge"));
                crossing.setStatus(resultSet.getString("status"));
                favoriteCrossings.add(crossing);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return favoriteCrossings;
    }

    public void addToFavorites(int crossingId) {
        try (Connection connection = DBConnection.getConnection()) {
            String sql = "INSERT INTO favcrossing (id) VALUES (?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, crossingId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }

    public void removeFromFavorites(int crossingId) {
        try (Connection connection = DBConnection.getConnection()) {
            String sql = "DELETE FROM favcrossing WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, crossingId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as needed
        }
    }
}
