package com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.Dao.CrossingDao;
import com.model.railwayCrossing;
/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String idParam = request.getParameter("crossingId");
			if (idParam != null && !idParam.isEmpty()) {
			int crossingId = Integer.parseInt(idParam);
			String name = request.getParameter("name");
			String address = request.getParameter("address");
			String landmark = request.getParameter("landmark");
			String trainSchedules =request.getParameter("trainSchedule");
			String personInCharge =request.getParameter("personInCharge");
			String status = request.getParameter("status");
			railwayCrossing updatedCrossing = new railwayCrossing();
			updatedCrossing.setId(crossingId);
			updatedCrossing.setName(name);
			updatedCrossing.setAddress(address);
			updatedCrossing.setLandmark(landmark);
			updatedCrossing.setTrainSchedule(trainSchedules);
			updatedCrossing.setPersonInCharge(personInCharge);
			updatedCrossing.setStatus(status);
			CrossingDao crossingDAO = new CrossingDao();
			crossingDAO.updateCrossing(updatedCrossing);
			response.sendRedirect("adminHome.jsp");
			} else {
			throw new ServletException("Crossing ID is missing.");
			}
			} catch (NumberFormatException e) {
			throw new ServletException("Invalid Crossing ID format.", e);
			} catch (Exception e) {
			throw new ServletException("An error occurred during the crossing update.", e);
			}
	}

}
