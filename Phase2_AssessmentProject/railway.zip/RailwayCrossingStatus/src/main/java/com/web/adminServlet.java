package com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.CrossingDao;

public class adminServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CrossingDao crossingDAO;

    public void init() {
        crossingDAO = new CrossingDao();
    }

    private static final String ID = "admin@email.com";
    private static final String PASSWORD = "admin507";

    public adminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        if (email != null && email.equals(ID) && password != null && password.equals(PASSWORD)) {
            response.sendRedirect("adminHome.jsp");
        } else {
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
        }
    }
}
