package com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.Dao.CrossingDao;
import com.model.railwayCrossing;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int searchId = Integer.parseInt(request.getParameter("searchId"));
		CrossingDao crossingDAO = new CrossingDao();
		railwayCrossing crossing = crossingDAO.getCrossingById(searchId);
		request.setAttribute("crossing", crossing);
		request.getRequestDispatcher("adminHome.jsp").forward(request,response);

	}

}
