package com.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.CrossingDao;
import com.model.railwayCrossing;

@WebServlet("/addCrossing")
public class addCrossing extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String address = request.getParameter("address");
        String landmark = request.getParameter("landmark");
        String trainSchedules = request.getParameter("trainSchedule");
        String personInCharge = request.getParameter("personInCharge");
        String status = request.getParameter("status");

        railwayCrossing crossing = new railwayCrossing();
        crossing.setName(name);
        crossing.setAddress(address);
        crossing.setLandmark(landmark);
        crossing.setPersonInCharge(personInCharge);
        crossing.setTrainSchedule(trainSchedules);
        crossing.setStatus(status);

        CrossingDao crossingDAO = new CrossingDao();
        crossingDAO.addCrossing(crossing);
        response.sendRedirect("adminHome.jsp");
    }
}
